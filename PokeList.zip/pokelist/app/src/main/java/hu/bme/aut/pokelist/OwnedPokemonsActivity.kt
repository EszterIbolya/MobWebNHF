package hu.bme.aut.pokelist

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import hu.bme.aut.pokelist.data.OwnedDatabase
import hu.bme.aut.pokelist.data.Pokemon
import hu.bme.aut.pokelist.databinding.ActivityPokemonsBinding
import hu.bme.aut.pokelist.fragments.NewPokemonItemFragment
import kotlin.concurrent.thread

class OwnedPokemonsActivity : AppCompatActivity(), PokemonAdapter.PokemonItemClickListener,
    NewPokemonItemFragment.NewPokemonItemDialogListener  {
    private lateinit var binding: ActivityPokemonsBinding
    private lateinit var database: OwnedDatabase
    private lateinit var adapter: PokemonAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPokemonsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        database = OwnedDatabase.getDatabase(applicationContext)

        binding.fab.setOnClickListener {
            NewPokemonItemFragment().show(
                supportFragmentManager,
                NewPokemonItemFragment.TAG
            )
        }

        initRecyclerView()
    }


    private fun initRecyclerView() {
        adapter = PokemonAdapter(this)
        binding.rvMain.layoutManager = LinearLayoutManager(this)
        binding.rvMain.adapter = adapter
        loadItemsInBackground()
    }

    private fun loadItemsInBackground() {
        thread {
            val items = database.PokemonDao().getAll()
            runOnUiThread {
                adapter.update(items)
            }
        }
    }
    override fun onItemChanged(item: Pokemon) {
        thread {
            database.PokemonDao().update(item)
        }
    }

    override fun onPokemonItemCreated(newItem: Pokemon) {
        thread {
            database.PokemonDao().insert(newItem)

            runOnUiThread {
                adapter.addItem(newItem)
            }
        }
    }

    override fun onItemDeleted(Item: Pokemon){
        thread {
            database.PokemonDao().deleteItem(Item)

            runOnUiThread {
                adapter.removeItem(Item)
            }
        }
    }
}