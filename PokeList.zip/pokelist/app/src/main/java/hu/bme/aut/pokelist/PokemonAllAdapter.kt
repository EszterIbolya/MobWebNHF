package hu.bme.aut.pokelist

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.annotation.DrawableRes
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import hu.bme.aut.pokelist.data.Pokemon
import hu.bme.aut.pokelist.data.PokemonfromApi
import hu.bme.aut.pokelist.databinding.ItemAllpokemonListBinding

class PokemonAllAdapter(val context: AllPokemonsActivity) :
    RecyclerView.Adapter<PokemonAllAdapter.PokemonViewHolder>() {

    private val items = mutableListOf<PokemonfromApi>()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = PokemonViewHolder(

        ItemAllpokemonListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )

    override fun onBindViewHolder(holder: PokemonViewHolder, position: Int) {
        val Pokemon = items[position]

        Glide.with(context)
            .load(Pokemon.sprites.front_default)
            .centerCrop()
            .placeholder(R.drawable.pokeball)
            .into(holder.binding.ivIcon)
        holder.binding.tvName.text = Pokemon.name
        holder.binding.tvCategory.text = Pokemon.types[0].type.name.uppercase()

    }

    @DrawableRes()
    private fun getImageResource(category: String): Int {
        return when (category) {

            else -> R.drawable.pokeball
        }
    }

    fun addItem(item: PokemonfromApi) {
        items.add(item)
        notifyItemInserted(items.size - 1)
    }

    override fun getItemCount(): Int = items.size

    fun update(Pokemons: List<PokemonfromApi>) {
        items.clear()
        items.addAll(Pokemons)
        notifyDataSetChanged()
    }

    inner class PokemonViewHolder(val binding: ItemAllpokemonListBinding) : RecyclerView.ViewHolder(binding.root)
}
