package hu.bme.aut.pokelist.data

data class GenerationIv(
    val diamondpearl: DiamondPearl,
    val heartgoldsoulsilver: HeartgoldSoulsilver,
    val platinum: Platinum
)