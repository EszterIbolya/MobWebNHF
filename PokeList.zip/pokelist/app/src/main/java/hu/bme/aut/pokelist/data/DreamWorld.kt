package hu.bme.aut.pokelist.data

data class DreamWorld(
    val front_default: String,
    val front_female: Any
)