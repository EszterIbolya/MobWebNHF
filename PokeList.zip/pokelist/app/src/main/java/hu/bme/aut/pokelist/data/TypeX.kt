package hu.bme.aut.pokelist.data

data class TypeX(
    val name: String,
    val url: String
)