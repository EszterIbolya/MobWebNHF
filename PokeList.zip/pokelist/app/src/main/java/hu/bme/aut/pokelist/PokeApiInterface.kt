package hu.bme.aut.pokelist

import hu.bme.aut.pokelist.data.ApiUrl
import hu.bme.aut.pokelist.data.PokemonfromApi
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path

interface PokeApiInterface {
    @GET("pokemon/{id}")
    fun getInfo(@Path("id")i: Int): Call<PokemonfromApi>

    @GET("pokemon?limit=50&offset=0")
    fun getAll(): Call<ApiUrl>
}