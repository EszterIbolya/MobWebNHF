package hu.bme.aut.pokelist.data

data class OfficialArtwork(
    val front_default: String
)