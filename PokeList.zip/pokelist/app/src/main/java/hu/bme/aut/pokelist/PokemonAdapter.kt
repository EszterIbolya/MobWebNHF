package hu.bme.aut.pokelist

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.annotation.DrawableRes
import androidx.recyclerview.widget.RecyclerView
import hu.bme.aut.pokelist.data.Pokemon
import hu.bme.aut.pokelist.databinding.ItemPokemonListBinding

class PokemonAdapter(private val listener: PokemonItemClickListener) :
    RecyclerView.Adapter<PokemonAdapter.PokemonViewHolder>() {

    private val items = mutableListOf<Pokemon>()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = PokemonViewHolder(

        ItemPokemonListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )

    override fun onBindViewHolder(holder: PokemonViewHolder, position: Int) {
        val Pokemon = items[position]

        holder.binding.ivIcon.setImageResource(getImageResource(Pokemon.category))
        holder.binding.tvName.text = Pokemon.name
        holder.binding.tvDescription.text = Pokemon.description
        holder.binding.tvCategory.text = Pokemon.category.name

        holder.binding.ibRemove.setOnClickListener{
            listener.onItemDeleted(Pokemon)
        }

    }

    @DrawableRes()
    private fun getImageResource(category: Pokemon.Category): Int {
        return when (category) {

            else -> R.drawable.pokeball
        }
    }


    override fun getItemCount(): Int = items.size

    fun addItem(item: Pokemon) {
        items.add(item)
        notifyItemInserted(items.size - 1)
    }

    fun update(Pokemons: List<Pokemon>) {
        items.clear()
        items.addAll(Pokemons)
        notifyDataSetChanged()
    }

    fun removeItem(item: Pokemon) {
        val position = items.indexOf(item)
        items.remove(item)
        notifyItemRemoved(position)
    }

    interface PokemonItemClickListener {
        fun onItemChanged(item: Pokemon)
        fun onItemDeleted(item: Pokemon)
    }

    inner class PokemonViewHolder(val binding: ItemPokemonListBinding) : RecyclerView.ViewHolder(binding.root)
}
