package hu.bme.aut.pokelist

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import hu.bme.aut.pokelist.data.ApiUrl
import hu.bme.aut.pokelist.data.Pokemon
import hu.bme.aut.pokelist.data.PokemonfromApi
import hu.bme.aut.pokelist.databinding.ActivityAllPokemonsBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import kotlin.concurrent.thread

class AllPokemonsActivity : AppCompatActivity(){
    private lateinit var binding: ActivityAllPokemonsBinding
    private lateinit var adapter: PokemonAllAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAllPokemonsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initRecyclerView()
    }

    private fun initRecyclerView() {
        adapter = PokemonAllAdapter(this)
        binding.rvMain.layoutManager = LinearLayoutManager(this)
        binding.rvMain.adapter = adapter
        loadItemsInBackground()
    }

    private fun loadItemsInBackground() {
        thread {
            val retrofit = Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl("https://pokeapi.co/api/v2/")
                .build()

            val pokeapi = retrofit.create(PokeApiInterface::class.java)
            val mcall: Call<ApiUrl> = pokeapi.getAll()
            mcall.enqueue(object: Callback<ApiUrl>
            {
                override fun onFailure(call: Call<ApiUrl>, t: Throwable) {
                    Log.d("1","hiba")
                }

                override fun onResponse(call: Call<ApiUrl>, response1: Response<ApiUrl>) {
                    val responseBody = response1.body()!!
                    var c: Int = 1
                    for(i in responseBody.results){
                        val pcall: Call<PokemonfromApi> = pokeapi.getInfo(c)
                        pcall.enqueue(object: Callback<PokemonfromApi>
                        {
                            override fun onFailure(call: Call<PokemonfromApi>, t: Throwable) {
                                Log.d("2","hiba")
                            }

                            override fun onResponse(call: Call<PokemonfromApi>, response2: Response<PokemonfromApi>) {
                                val poke: PokemonfromApi = response2.body()!!
                                adapter.addItem(poke)
                            }
                        }
                        )
                        c++
                    }
                }
            })
        }
    }

}