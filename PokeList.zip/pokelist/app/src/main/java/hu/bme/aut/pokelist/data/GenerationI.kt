package hu.bme.aut.pokelist.data

data class GenerationI(
    val redblue: RedBlue,
    val yellow: Yellow
)