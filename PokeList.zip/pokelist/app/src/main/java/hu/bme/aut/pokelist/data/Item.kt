package hu.bme.aut.pokelist.data

data class Item(
    val name: String,
    val url: String
)