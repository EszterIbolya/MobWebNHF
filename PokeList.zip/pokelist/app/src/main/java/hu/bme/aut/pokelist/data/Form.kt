package hu.bme.aut.pokelist.data

data class Form(
    val name: String,
    val url: String
)