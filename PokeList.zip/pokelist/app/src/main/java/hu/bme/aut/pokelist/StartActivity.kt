package hu.bme.aut.pokelist

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import hu.bme.aut.pokelist.databinding.ActivityStartBinding
import android.preference.PreferenceManager
import java.text.SimpleDateFormat
import java.util.*


class StartActivity : AppCompatActivity() {
    private lateinit var binding: ActivityStartBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStartBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val pref: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)
        binding.textView3.setText(pref.getString("last_active",""))
        binding.btnStart.setOnClickListener {
            startActivity(Intent(this, ListActivity::class.java))
        }
    }

    override fun onResume() {
        val editor: SharedPreferences.Editor = PreferenceManager.getDefaultSharedPreferences(this).edit()
        val sdf = SimpleDateFormat("yyyy/M/dd hh:mm")
        val currentDate = sdf.format(Date())
        editor.putString("last_active", currentDate)
        editor.apply()
        super.onResume()
    }
}