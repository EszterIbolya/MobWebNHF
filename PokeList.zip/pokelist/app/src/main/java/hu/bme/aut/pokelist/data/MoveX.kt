package hu.bme.aut.pokelist.data

data class MoveX(
    val name: String,
    val url: String
)