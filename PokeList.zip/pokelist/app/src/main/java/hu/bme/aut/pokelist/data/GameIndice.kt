package hu.bme.aut.pokelist.data

data class GameIndice(
    val game_index: Int,
    val version: Version
)