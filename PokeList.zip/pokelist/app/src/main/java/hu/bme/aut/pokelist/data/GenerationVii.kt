package hu.bme.aut.pokelist.data

data class GenerationVii(
    val icons: Icons,
    val ultrasunultramoon: UltraSunUltraMoon
)