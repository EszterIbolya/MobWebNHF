package hu.bme.aut.pokelist.data

data class GenerationIii(
    val emerald: Emerald,
    val fireredleafgreen: FireredLeafgreen,
    val rubysapphire: RubySapphire
)