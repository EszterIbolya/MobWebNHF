package hu.bme.aut.pokelist.data

data class VersionDetail(
    val rarity: Int,
    val version: VersionX
)