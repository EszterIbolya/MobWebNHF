package hu.bme.aut.pokelist.data

data class GenerationVi(
    val omegarubyalphasapphire: OmegarubyAlphasapphire,
    val xy: XY
)