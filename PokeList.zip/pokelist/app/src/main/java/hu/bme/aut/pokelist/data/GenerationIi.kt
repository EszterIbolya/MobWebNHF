package hu.bme.aut.pokelist.data

data class GenerationIi(
    val crystal: Crystal,
    val gold: Gold,
    val silver: Silver
)