package hu.bme.aut.pokelist.data

data class MoveLearnMethod(
    val name: String,
    val url: String
)