package hu.bme.aut.pokelist.data

data class VersionGroup(
    val name: String,
    val url: String
)