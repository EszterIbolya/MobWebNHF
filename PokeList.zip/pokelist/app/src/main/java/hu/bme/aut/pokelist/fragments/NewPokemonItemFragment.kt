package hu.bme.aut.pokelist.fragments

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import hu.bme.aut.pokelist.R
import hu.bme.aut.pokelist.data.Pokemon
import hu.bme.aut.pokelist.databinding.DialogNewPokemonItemBinding

class NewPokemonItemFragment : DialogFragment() {
    interface NewPokemonItemDialogListener {
        fun onPokemonItemCreated(newItem: Pokemon)
    }

    private lateinit var listener: NewPokemonItemDialogListener

    private lateinit var binding: DialogNewPokemonItemBinding

    override fun onAttach(context: Context) {
        super.onAttach(context)
        listener = context as? NewPokemonItemDialogListener
            ?: throw RuntimeException("Activity must implement the NewPokemonItemDialogListener interface!")
    }

    private fun isValid() = binding.etName.text.isNotEmpty()

    private fun getPokemonItem() = Pokemon(
        name = binding.etName.text.toString(),
        description = binding.etDescription.text.toString(),
        category = Pokemon.Category.getByOrdinal(binding.spCategory.selectedItemPosition)
            ?: Pokemon.Category.NORMAL,
    )


    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        binding = DialogNewPokemonItemBinding.inflate(LayoutInflater.from(context))
        binding.spCategory.adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            resources.getStringArray(hu.bme.aut.pokelist.R.array.category_items)
        )

        return AlertDialog.Builder(requireContext())
            .setTitle(hu.bme.aut.pokelist.R.string.new_pokemon_item)
            .setView(binding.root)
            .setPositiveButton(hu.bme.aut.pokelist.R.string.button_ok) { dialogInterface, i ->
                if (isValid()) {
                    listener.onPokemonItemCreated(getPokemonItem())
                }
            }
            .setNegativeButton(hu.bme.aut.pokelist.R.string.button_cancel, null)
            .create()
    }

    companion object {
        const val TAG = "NewPokemonItemDialogFragment"
    }
}