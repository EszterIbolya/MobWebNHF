package hu.bme.aut.pokelist.data

data class ApiUrl (
    val count: Int,
    val next: String,
    val previous: Int,
    var results: Array<NameUrl>
)