package hu.bme.aut.pokelist.data

data class NameUrl (
    val name: String,
    val url: String
    )
