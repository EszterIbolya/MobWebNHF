package hu.bme.aut.pokelist.data

data class Emerald(
    val front_default: String,
    val front_shiny: String
)