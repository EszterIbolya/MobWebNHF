package hu.bme.aut.pokelist.data

data class Type(
    val slot: Int,
    val type: TypeX
)