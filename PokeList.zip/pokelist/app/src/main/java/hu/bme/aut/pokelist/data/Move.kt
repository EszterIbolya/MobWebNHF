package hu.bme.aut.pokelist.data

data class Move(
    val move: MoveX,
    val version_group_details: List<VersionGroupDetail>
)