package hu.bme.aut.pokelist.data

data class GenerationV(
    val blackwhite: BlackWhite
)