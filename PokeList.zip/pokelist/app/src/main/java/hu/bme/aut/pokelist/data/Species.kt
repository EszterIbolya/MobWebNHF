package hu.bme.aut.pokelist.data

data class Species(
    val name: String,
    val url: String
)