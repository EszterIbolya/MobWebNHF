package hu.bme.aut.pokelist.data

data class Other(
    val dream_world: DreamWorld,
    val home: Home,
    val officialartwork: OfficialArtwork
)