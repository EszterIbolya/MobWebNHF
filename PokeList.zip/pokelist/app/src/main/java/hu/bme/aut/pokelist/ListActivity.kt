package hu.bme.aut.pokelist

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageView
import hu.bme.aut.pokelist.databinding.ActivityListBinding

class ListActivity : AppCompatActivity() {
    private lateinit var binding: ActivityListBinding

    lateinit var anim1: Animation
    lateinit var image1: ImageView
    lateinit var anim2: Animation
    lateinit var image2: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        anim1 = AnimationUtils.loadAnimation(this,R.anim.topanimation)
        image1 = findViewById(R.id.pikachu)
        image1.setAnimation(anim1)

        anim2 = AnimationUtils.loadAnimation(this,R.anim.botanimation)
        image2 = findViewById(R.id.vulpix)
        image2.setAnimation(anim2)

        binding.btnOwned.setOnClickListener {
            val intent = Intent(this, OwnedPokemonsActivity::class.java)
            startActivity(intent)
        }
        binding.btnAll.setOnClickListener {
            val intent = Intent(this, AllPokemonsActivity::class.java)
            startActivity(intent)
        }
    }
}