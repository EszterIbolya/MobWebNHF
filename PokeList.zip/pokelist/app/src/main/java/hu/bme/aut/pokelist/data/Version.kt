package hu.bme.aut.pokelist.data

data class Version(
    val name: String,
    val url: String
)