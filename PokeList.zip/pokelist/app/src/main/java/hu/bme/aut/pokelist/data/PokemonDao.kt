package hu.bme.aut.pokelist.data

import androidx.room.*

@Dao
interface PokemonDao {
    @Query("SELECT * FROM pokemon")
    fun getAll(): List<Pokemon>

    @Insert
    fun insert(pokemons: Pokemon): Long

    @Update
    fun update(pokemon: Pokemon)

    @Delete
    fun deleteItem(pokemon: Pokemon)
}