package hu.bme.aut.pokelist.data

data class GenerationViii(
    val icons: IconsX
)