package hu.bme.aut.pokelist.data

data class StatX(
    val name: String,
    val url: String
)