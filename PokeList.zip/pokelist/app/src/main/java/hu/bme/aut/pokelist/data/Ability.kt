package hu.bme.aut.pokelist.data

data class Ability(
    val ability: AbilityX,
    val is_hidden: Boolean,
    val slot: Int
)